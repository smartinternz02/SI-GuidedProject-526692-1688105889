# SI-GuidedProject-526691-1688105893
Automatic Number Plate Recognition


Submitted By<br>
Kavneer Singh Mann (20BCE2232)<br>
Subhransu Sekhar Rout (20BBS0176)<br>
Akutota Sanjay (20BBS0175)<br>
Ansh (20BKT0133)
